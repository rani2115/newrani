from django.apps import AppConfig


class MypostConfig(AppConfig):
    name = 'mypost'
